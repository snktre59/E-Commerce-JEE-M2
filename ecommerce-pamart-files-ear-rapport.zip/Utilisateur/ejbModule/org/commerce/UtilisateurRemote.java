package org.commerce;

import javax.ejb.Remote;

@Remote
public interface UtilisateurRemote {
	
	public Utilisateur CreateInscription(String nom, String prenom, String email, String mdp, String numRue, String rue, String ville, String codePostal, String pays, String tel, String role);
	public Object Connexion(String email, String mdp);
}
